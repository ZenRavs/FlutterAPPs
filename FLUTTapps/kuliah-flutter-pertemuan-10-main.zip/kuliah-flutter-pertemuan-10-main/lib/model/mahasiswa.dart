class Mahasiswa {
  final String nim;
  final String nama;

  const Mahasiswa({
    required this.nama,
    required this.nim
  });
}