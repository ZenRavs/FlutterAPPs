package com.example.input_mahasiswa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
